<?php
header('Location: /index');
